# Brekky
**==AirBNB price alerts (like flight alerts)==**
- A tool that alerts people (like digital nomads) to any Airbnb's that come onto the market that are below a certain price point with certain criteria
- Even a tool that simply listed new Airbnb's that appeared on the market for a certain date
- Validation
	- https://www.reddit.com/r/digitalnomad/comments/tvxq12/accommodation_hacking_price_alerts_for_airbnb/
	- https://www.google.com/search?q=airbnb+price+alerts&oq=airbnb+price+alerts&aqs=chrome..69i57j69i60.3651j0j1&sourceid=chrome&ie=UTF-8
	- https://www.reddit.com/r/AirBnB/comments/bnrg9a/low_price_alert/


## Keys
- Firebase
	- Staging
		- API Key - AIzaSyCLbOSBrVTJOrK7NKUSadMTpCdAFmveQRw
		- Auth domain - brekky-dev.firebaseapp.com
		- Project ID - brekky-dev
		- Storage bucket - brekky-dev.appspot.com
		- Messaging sender ID - 392047075604
		- App ID - 1:392047075604:web:714b64ea436d5d23b96201
- Twitter
	- Staging (brekkyteam+dev@gmail.com)
		- API Key - peecMUjHT5I539zORQipSe65b
		- API Secret - 4qWr5ZNm0wf6ohOYYgidvzqWZXE7i7dHR6rGGb8WgbQzLq2Apa
		- Bearer Token - AAAAAAAAAAAAAAAAAAAAAG%2B7cQEAAAAACiqR8FzhyaPN1NE6kOeXRaf4%2FPU%3DS88C68AtitHA9fDHxdAJNKtgmkyL1xouZyKw6eoJNXZg15tmFK
- Facebook
	- Staging (brekkyteam+dev@gmail.com)
		- App ID - 1337635490057596
		- App Secret - 5db84c6f6995d4298290ca5d8e3a7c77
- Stripe
	- Emergency Backup Code - hviz-nnvr-umco-ceix-fdso
	- Test (Staging/Dev)
		- Publishable key - pk_test_51KxqUMBifXiQ8VACUPvlibrsWs3QNgwgUWrkCdpZvn9BPjY0jfrATpNIrdwe6DjMWc3nW5SMTOZqU1Agh9qa4aTm00nb9j4yeJ
		- Secret key - sk_test_51KxqUMBifXiQ8VACfTMOAoYR9KB2crKvvhUWnuUxXzPBuC7NWzXd4NZcinHnTRBdT7Fzdv0SS2CeBGSINenW8RMy00cfyrUjtB